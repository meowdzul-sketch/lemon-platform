import Link from 'next/link'

export default function Home(){ 
  return (
    <div className="min-h-screen bg-white p-6">
      <header className="flex justify-between items-center mb-6">
        <div className="text-xl font-bold flex items-center gap-2"><div className="w-8 h-8 rounded-full bg-[#FBBF24]"/>LemonPay</div>
        <div className="flex gap-4"><a href="/register" className="underline">Register</a></div>
      </header>

      <main>
        <section className="bg-[#FBBF24] rounded-lg p-8 text-black">
          <h1 className="text-3xl font-bold">LemonPay — Nombor Virtual Malaysia</h1>
          <p className="mt-2">Register, dapatkan RM1.00 percuma, beli nombor virtual RM1.00 sahaja.</p>
        </section>

        <section className="mt-6 grid grid-cols-1 sm:grid-cols-3 gap-4">
          {['Zus Coffee','Chagee','Tealive','KFC','FoodPanda','Other'].map(s => (
            <div key={s} className="p-4 border rounded">{s}</div>
          ))}
        </section>
      </main>
    </div>
  )
}
