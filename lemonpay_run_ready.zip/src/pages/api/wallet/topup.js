import prisma from '../../../lib/prisma.js'

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end()
  const { userId, amount } = req.body
  if (!userId || !amount || amount < 10) return res.status(400).json({ error: 'Invalid amount' })

  const tx = await prisma.transaction.create({ data: { userId, type: 'CREDIT', subtype: 'TOPUP', amountCents: Math.round(amount*100), status: 'PENDING' } })
  return res.status(200).json({ paymentUrl: 'https://toyyibpay.placeholder/checkout?tx=' + tx.id, txId: tx.id })
}
