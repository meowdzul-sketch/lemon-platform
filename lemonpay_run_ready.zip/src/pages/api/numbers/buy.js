import prisma from '../../../lib/prisma.js'

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end()
  const { userId, service } = req.body
  if (!userId || !service) return res.status(400).json({ error: 'Missing' })

  const wallet = await prisma.wallet.findUnique({ where: { userId } })
  if (!wallet || wallet.balanceCents < 100) return res.status(400).json({ error: 'Insufficient balance' })

  const updated = await prisma.wallet.update({ where: { id: wallet.id }, data: { balanceCents: wallet.balanceCents - 100 } })
  const tx = await prisma.transaction.create({ data: { userId, type: 'DEBIT', subtype: 'PURCHASE', amountCents: 100, status: 'SUCCESS' } })

  let number
  while (true) {
    number = '+60' + String(100000000 + Math.floor(Math.random() * 900000000))
    const exists = await prisma.virtualNumber.findUnique({ where: { number } }).catch(()=>null)
    if (!exists) break
  }
  const vn = await prisma.virtualNumber.create({ data: { userId, service, number } })
  return res.status(200).json({ ok: true, number: vn.number })
}
