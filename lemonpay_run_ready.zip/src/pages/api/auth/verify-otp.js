import prisma from '../../../lib/prisma.js'

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end()
  const { phone, code } = req.body
  if (!phone || !code) return res.status(400).json({ error: 'Missing' })

  const otp = await prisma.oTPCode.findFirst({ where: { phone, code, used: false }, orderBy: { createdAt: 'desc' } })
  if (!otp) return res.status(400).json({ error: 'Invalid OTP' })
  if (otp.expiresAt < new Date()) return res.status(400).json({ error: 'OTP expired' })

  await prisma.oTPCode.update({ where: { id: otp.id }, data: { used: true } })

  const user = await prisma.user.findUnique({ where: { phone } })
  if (!user) return res.status(404).json({ error: 'User not found' })

  const wallet = await prisma.wallet.findUnique({ where: { userId: user.id } })
  if (wallet.balanceCents === 0) {
    await prisma.wallet.update({ where: { id: wallet.id }, data: { balanceCents: wallet.balanceCents + 100 } })
    await prisma.transaction.create({ data: { userId: user.id, type: 'CREDIT', subtype: 'REGISTRATION_BONUS', amountCents: 100, status: 'SUCCESS' } })
  }

  return res.status(200).json({ ok: true, user: { id: user.id, email: user.email, phone: user.phone } })
}
