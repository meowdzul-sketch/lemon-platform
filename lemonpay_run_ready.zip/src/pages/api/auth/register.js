import prisma from '../../../lib/prisma.js'
import { randomInt } from 'crypto'
import { sendOTP } from '../../../lib/smsProvider.js'

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end()
  const { email, phone } = req.body
  if (!email || !phone) return res.status(400).json({ error: 'Missing email or phone' })

  let user = await prisma.user.findUnique({ where: { phone } })
  if (!user) {
    user = await prisma.user.create({ data: { email, phone } })
    await prisma.wallet.create({ data: { userId: user.id, balanceCents: 0 } })
  }

  const code = String(100000 + randomInt(900000))
  const expiresAt = new Date(Date.now() + 5*60*1000)
  await prisma.oTPCode.create({ data: { phone, code, expiresAt } })
  await sendOTP(phone, code)
  return res.status(200).json({ ok: true })
}
