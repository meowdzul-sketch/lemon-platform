# LemonPay — Run-ready Scaffold

This ZIP contains a minimal Next.js scaffold for the LemonPay MVP (Fullstack: Frontend + API routes).

IMPORTANT SECURITY:
- This archive includes your API keys inside `.env.example` because you requested a runnable package.
- **Do not commit `.env` or these keys to any public GitHub repo.**
- Rotate these keys if you plan to publish the repo.

Quickstart:
1. Extract the ZIP.
2. Install: `npm install`
3. Copy `.env.example` to `.env` and adjust `DATABASE_URL` to your local Postgres, or use SQLite if preferred.
4. Run Prisma migrate (if using a DB): `npx prisma migrate dev --name init`
5. Start dev server: `npm run dev`

Notes:
- This is a minimal scaffold for local development and testing. It is NOT production-ready.
- Implement proper auth/session management, input validation, rate-limiting, and secure webhook verification for production.
