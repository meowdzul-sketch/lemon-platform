export default {reactStrictMode: true}
