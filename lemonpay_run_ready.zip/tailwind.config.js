module.exports = {content: ['./src/**/*.{js,jsx}']}
